__version__            = "0.9.27"
__configuration_path__ = "/etc/thug"
