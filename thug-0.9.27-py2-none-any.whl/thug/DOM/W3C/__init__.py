__all__ = ['w3c',
           'Core',
           'HTML']
